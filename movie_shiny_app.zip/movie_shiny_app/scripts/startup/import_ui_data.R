
import_ui_data <- function() {
  genre_names <<- readRDS('ui_data/genre_names.RDS') 
}

import_ui_data()